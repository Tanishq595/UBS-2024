const express = require('express');
const morganBody = require('morgan-body');

const app = express().use(express.json());
morganBody(app, { noColors: process.env.NODE_ENV === 'production' });


app.get('/', (req, res) => {
  res.send('Welcome to the API!');
});

app.post("/bugfixer/p2", (req, res) => {
    try{
        function max_bugsfixed(bugseq) {
            let currentTime = 0;
            let bugsFixed = 0;
        
            // Sort bugseq by the limit (deadline) in ascending order
            // bugseq.sort((a, b) => a[1] - b[1]);
        
            for (let i = 0; i < bugseq.length; i++) {
              let [difficulty, limit] = bugseq[i];
              if (currentTime + difficulty <= limit) {
                currentTime += difficulty;
                bugsFixed++;
              }
            }
        
            return bugsFixed;
          }
        
          const inputArray = req.body;
        
          const output = inputArray.map(item => {
            if (!item.bugseq || !Array.isArray(item.bugseq)) {
              return "Invalid 'bugseq' array.";
            }
            return max_bugsfixed(item.bugseq);
          });
        
          res.json(output);  
    }catch(err){
        res.json(err);
    }});


    app.post("/lisp-parser", (req, res) => {
        try{
            class Interpreter {
                constructor() {
                    this.variables = {};
                }
            
                run(expression) {
                    expression = expression.trim().slice(1, -1);  // Remove the parentheses
                    const [func, ...args] = expression.split(" ");
            
                    switch (func) {
                        case "puts":
                            return this.puts(...args);
                        case "set":
                            return this.set(...args);
                        case "concat":
                            return this.concat(...args);
                        case "lowercase":
                            return this.lowercase(...args);
                        case "uppercase":
                            return this.uppercase(...args);
                        case "replace":
                            return this.replace(...args);
                        case "substring":
                            return this.substring(...args);
                        case "add":
                            return this.add(...args);
                        case "subtract":
                            return this.subtract(...args);
                        case "multiply":
                            return this.multiply(...args);
                        case "divide":
                            return this.divide(...args);
                        case "abs":
                            return this.abs(...args);
                        case "max":
                            return this.max(...args);
                        case "min":
                            return this.min(...args);
                        case "gt":
                            return this.gt(...args);
                        case "lt":
                            return this.lt(...args);
                        case "equal":
                            return this.equal(...args);
                        case "str":
                            return this.str(...args);
                        default:
                            return "Unsupported function";
                    }
                }
            
                puts(...args) {
                    return args.map(arg => this.parseValue(arg)).join(" ");
                }
            
                set(varName, value) {
                    if (this.variables.hasOwnProperty(varName)) {
                        return "Error: Variable already declared";
                    }
                    this.variables[varName] = this.parseValue(value);
                    return null;
                }
            
                parseValue(value) {
                    if (value === "true") return true;
                    if (value === "false") return false;
                    if (value === "null") return null;
                    if (!isNaN(value)) return parseFloat(value);
                    if (value.startsWith('"') && value.endsWith('"')) return value.slice(1, -1);
                    return value;
                }
            
                concat(...args) {
                    return args.map(arg => this.parseValue(arg)).join("");
                }
            
                lowercase(str) {
                    return this.parseValue(str).toLowerCase();
                }
            
                uppercase(str) {
                    return this.parseValue(str).toUpperCase();
                }
            
                replace(str, find, replace) {
                    let parts = this.parseValue(str).split(this.parseValue(find));
                    return parts.join(this.parseValue(replace));
                }
            
                substring(str, start, end) {
                    return this.parseValue(str).slice(parseInt(start), parseInt(end));
                }
            
                add(...args) {
                    return args.reduce((a, b) => +a + +b, 0);
                }
            
                subtract(...args) {
                    return args.reduce((a, b) => +a - +b);
                }
            
                multiply(...args) {
                    return args.reduce((a, b) => +a * +b, 1);
                }
            
                divide(...args) {
                    return args.reduce((a, b) => +a / +b);
                }
            
                abs(num) {
                    return Math.abs(+num);
                }
            
                max(...args) {
                    return Math.max(...args);
                }
            
                min(...args) {
                    return Math.min(...args);
                }
            
                gt(a, b) {
                    return +a > +b;
                }
            
                lt(a, b) {
                    return +a < +b;
                }
            
                equal(a, b) {
                    return a == b;
                }
            
                str(value) {
                    return String(this.parseValue(value));
                }
            }
            
            // Example usage
            // const input = {
            //     "expressions": [
            //         "(puts \"Hello\")",
            //         "(puts \"World!\")"
            //     ]
            // };
            
            const input = req.body;
            
            if (!input || !Array.isArray(input.expressions)) {
              return res.status(400).json({ error: "Invalid input. Expected an object with an 'expressions' array." });
            }
            
            
            const interpreter = new Interpreter();
            
            const output = input.expressions.map(expression => interpreter.run(expression));
            
            res.json(output);
        }catch(err){
            res.json(err);
        }
      
    
    });

app.post("/bugfixer/p1", (req, res) => {
    try{
        function calculateMinimumHours(time, prerequisites) {
            const n = time.length;
            const indegree = Array(n).fill(0);
            const adjList = Array.from({ length: n }, () => []);
        
            prerequisites.forEach(([a, b]) => {
                adjList[a - 1].push(b - 1);
                indegree[b - 1]++;
            });
        
            const queue = [];
            const completionTime = [...time];
        
            for (let i = 0; i < n; i++) {
                if (indegree[i] === 0) {
                    queue.push(i);
                }
            }
        
            while (queue.length) {
                const current = queue.shift();
                adjList[current].forEach((neighbor) => {
                    completionTime[neighbor] = Math.max(completionTime[neighbor], completionTime[current] + time[neighbor]);
                    indegree[neighbor]--;
                    if (indegree[neighbor] === 0) {
                        queue.push(neighbor);
                    }
                });
            }
        
            return Math.max(...completionTime);
        }
        
        // Example usage
        // const projects = [
        //     {
        //         time: [3, 6, 9],
        //         prerequisites: [[1, 3], [2, 3]]
        //     },
        //     {
        //         time: [3, 6, 9],
        //         prerequisites: []
        //     },
        //     {
        //         time: [1, 2, 3, 4, 5],
        //         prerequisites: [[1, 2], [3, 4], [2, 5], [4, 5]]
        //     },
        //     {
        //         time: [1, 2, 3, 4, 5, 13],
        //         prerequisites: [[1, 2], [3, 4], [2, 5], [4, 5]]
        //     }
        // ];
        
        const inputArray = req.body;
        const results = inputArray.map(({ time, prerequisites }) => calculateMinimumHours(time, prerequisites));
        res.json(results); // Output: [15, 9, 12, 13]

    }catch(err){
        res.json(err);
}});

app.post("/klotski", (req, res) => {
    try{
        const directions = {
            'N': [-1, 0],
            'S': [1, 0],
            'W': [0, -1],
            'E': [0, 1]
        };

        function parseBoard(boardStr) {
            let board = [];
            for (let i = 0; i < 5; i++) {
                board.push(boardStr.slice(i * 4, i * 4 + 4).split(''));
            }
            return board;
        }

        function stringifyBoard(board) {
            return board.flat().join('');
        }

        function findBlock(board, block) {
            let positions = [];
            for (let r = 0; r < 5; r++) {
                for (let c = 0; c < 4; c++) {
                    if (board[r][c] === block) {
                        positions.push([r, c]);
                    }
                }
            }
            return positions;
        }

        function isMoveValid(board, positions, dir) {
            for (let [r, c] of positions) {
                let [dr, dc] = directions[dir];
                let nr = r + dr, nc = c + dc;
                if (nr < 0 || nr >= 5 || nc < 0 || nc >= 4 || (board[nr][nc] !== '@' && !positions.some(([pr, pc]) => pr === nr && pc === nc))) {
                    return false;
                }
            }
            return true;
        }

        function moveBlock(board, block, dir) {
            let positions = findBlock(board, block);
            if (!isMoveValid(board, positions, dir)) return;
            
            let [dr, dc] = directions[dir];
            positions.forEach(([r, c]) => board[r][c] = '@');
            positions = positions.map(([r, c]) => [r + dr, c + dc]);
            positions.forEach(([r, c]) => board[r][c] = block);
        }
    
        const result = req.body.map(({ board, moves }) => {
            let currentBoard = parseBoard(board);
            for (let i = 0; i < moves.length; i += 2) {
                let block = moves[i];
                let direction = moves[i + 1];
                moveBlock(currentBoard, block, direction);
            }
            return stringifyBoard(currentBoard);
        });

        res.json(result);
    }catch(err){
        res.json(err);
    }
});

app.post('/efficient-hunter-kazuma', (req, res) => {
    const results = req.body.map(({ monsters }) => {
      const n = monsters.length;
      if (n <= 1) return { efficiency: 0 };
  
      let dp = new Array(n).fill(0);
  
      for (let i = 1; i < n; i++) {
        dp[i] = dp[i - 1]; // Carry forward previous efficiency
  
        for (let j = 0; j < i; j++) {
          const gain = monsters[i];
          const cost = monsters[j];
          const currentEfficiency = gain - cost;
  
          if (currentEfficiency > 0) {
            dp[i] = Math.max(dp[i], (j > 0 ? dp[j - 1] : 0) + currentEfficiency);
          }
        }
      }
  
      return { efficiency: Math.max(...dp) };
    });
  
    res.json(results);
  });
  

//   app.post('/the-clumsy-programmer', (req, res) => {
//     try {
//       function findCorrections(testCases) {
//         return testCases.map(({ dictionary, mistypes }) => {
//           const corrections = mistypes.map(mistypedWord => {
//             for (const correctWord of dictionary) {
//               if (mistypedWord.length !== correctWord.length) continue;
  
//               let diffCount = 0;
//               for (let i = 0; i < mistypedWord.length; i++) {
//                 if (mistypedWord[i] !== correctWord[i]) {
//                   diffCount++;
//                 }
  
//                 if (diffCount > 1) break;
//               }
  
//               if (diffCount === 1) {
//                 return " ";
//               }
//             }
//             return null; // No match found
//           });
  
//           return { corrections };
//         });
//       }
  
//       const input = req.body;
//       const output = findCorrections(input);
//     //   const output = [];
//       res.json(output);
//     } catch (err) {
//       res.json(err);
//     }
//   });

//   app.post('/the-clumsy-programmer', (req, res) => {
//     try {
//       function correctMistypes(dictionary, mistypes) {
//         const corrections = mistypes.map(mistypedWord => {
//           for (let correctWord of dictionary) {
//             let mismatchCount = 0;
//             for (let i = 0; i < correctWord.length; i++) {
//               if (correctWord[i] !== mistypedWord[i]) {
//                 mismatchCount++;
//                 if (mismatchCount > 1) break;
//               }
//             }
//             if (mismatchCount === 1) {
//               return correctWord;
//             }
//           }
//           return mistypedWord; // In case no match is found, which shouldn't happen as per the problem statement
//         });
      
//         return corrections;
//       }
      
//       // Example usage:
//     //   const input = [
//     //     {
//     //       dictionary: ["apple", "banana", "cherry"],
//     //       mistypes: ["apqle", "banqna", "cherqy"]
//     //     }
//     //   ];

//     const input = req.body;

//       const output = input.map(({ dictionary, mistypes }) => ({
//         corrections: correctMistypes(dictionary, mistypes)
//       }));
      
//       res.json(output);
//       // Output: [{ corrections: ["purple", "gadget", "rocket", "silver"] }]
//     } catch (err) {
//       res.json(err);
//     }
//   });

app.post('/the-clumsy-programmer', (req, res) => {
    try {
        function findCorrectWord(dictionary, mistypedWord) {
            for (const word of dictionary) {
              if (isOneLetterMistype(word, mistypedWord)) {
                return word;
              }
            }
            return mistypedWord; // Fallback, should not happen as per problem statement
          }
          
          function isOneLetterMistype(correctWord, mistypedWord) {
            if (correctWord.length !== mistypedWord.length) return false;
          
            let mismatchCount = 0;
          
            for (let i = 0; i < correctWord.length; i++) {
              if (correctWord[i] !== mistypedWord[i]) {
                mismatchCount++;
              }
          
              if (mismatchCount > 1) {
                return false;
              }
            }
          
            return mismatchCount === 1;
          }
      const input = req.body;
  
      if (!Array.isArray(input)) {
        return res.status(400).json({ error: "Expected an array of test cases." });
      }
  
      const results = input.map(({ dictionary, mistypes }) => {
        const corrections = mistypes.map(mistypedWord => {
          return findCorrectWord(dictionary, mistypedWord);
        });
  
        return { corrections };
      });
  
      res.json(results);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  
  app.post('/digital-colony', (req, res) => {
    try {
        function totalSum(num) {
            let sum = 0n;
            while (num > 0n) 
              {
                sum += num % 10n; 
                num = num / 10n;
            }
            return sum;
          }
          
          let TOTAL_WEIGHT = 0n;
          
          function calculateWeight(colony, generations) {
            generations = BigInt(generations);
            if (generations === 0n) {
                return totalSum(BigInt(colony));
            }
          
            let res_string = "";
            let weight = TOTAL_WEIGHT;
            for (let i = 0; i < colony.length-1; i++) {
                let first = BigInt(colony[i]);
                let second = BigInt(colony[i + 1]) || 0n;
                res_string += colony[i];
          
                let sig;
                if (first > second) {
                    sig = first - second;
                } else if (first < second) {
                    sig = 10n + first - second;
                } else {
                    sig = 0n;
                }
          
                let res = (weight + sig) % 10n;
                TOTAL_WEIGHT += res;
                res_string += res.toString();
            }
            res_string += colony[colony.length-1];
          
            return calculateWeight(res_string, generations - 1n);
          }
          
          const input = req.body
          TOTAL_WEIGHT += totalSum(BigInt(colony));
          calculateWeight(input.colony, input.generations);
          res.json(TOTAL_WEIGHT);          
    } catch (err) {
      res.json(err);
    }
  });



module.exports = app;